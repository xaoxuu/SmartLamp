//
//  DeviceViewController.h
//  SmartLamp
//
//  Created by Aesir Titan on 2016-07-13.
//  Copyright © 2016年 Titan Studio. All rights reserved.
//

#import "ATBaseViewController.h"

@interface DeviceViewController : ATBaseViewController

@end
