//
//  HomeViewController.h
//  SmartLamp
//
//  Created by Aesir Titan on 2016-07-13.
//  Copyright © 2016年 Titan Studio. All rights reserved.
//

#import "ATBaseViewController.h"
#import "StatusView.h"
#import "ColorModeView.h"
#import "TimerView.h"

@interface HomeViewController : ATBaseViewController


@end

