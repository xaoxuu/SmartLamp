//
//  ProfilesDetailsViewController.h
//  SmartLamp
//
//  Created by Aesir Titan on 2016-05-10.
//  Copyright © 2016 Titan Studio. All rights reserved.
//

#import "ViewController.h"

@interface ProfilesDetailsViewController : ViewController



@end
